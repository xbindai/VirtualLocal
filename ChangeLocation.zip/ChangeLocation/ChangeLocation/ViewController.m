//
//  ViewController.m
//  ChangeLocation
//
//  Created by ljb48229 on 2018/1/26.
//  Copyright © 2018年 ljb48229. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
#import "ChangeLoction.h"

@interface ViewController ()<CLLocationManagerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //1.去高德地图http://lbs.amap.com/console/show/picker，选中自己坐标
    //2.在进行坐标转换
    CLLocationCoordinate2D location2D = CLLocationCoordinate2DMake(22.53351, 113.953811);
    CLLocationCoordinate2D WGSlocation2D = [ChangeLoction gcj02ToWgs84:location2D];
    NSLog(@"纬度：%f,经度：%f",WGSlocation2D.latitude , WGSlocation2D.longitude);
    //纬度：30.277029,经度：120.207428
    //3.去Location1.gpx修改经纬度
}

@end
